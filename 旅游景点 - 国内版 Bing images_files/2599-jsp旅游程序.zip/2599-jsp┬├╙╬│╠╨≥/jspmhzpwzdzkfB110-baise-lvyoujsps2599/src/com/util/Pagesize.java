package com.util;

public class Pagesize
{
	public static int size=4;

}
