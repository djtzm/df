package com.model;

/**
 * leibie entity. @author MyEclipse Persistence Tools
 */

public class leibie implements java.io.Serializable
{
    /*������*/
	private  java.lang.Integer  id;
	private  java.lang.String  mingcheng;

    /*��������*/

    /*�з���*/
	public java.lang.Integer  getId() {
		return id;
	}
	public void  setId(java.lang.Integer id) {
		this.id = id;
	}
	public java.lang.String  getMingcheng() {
		return mingcheng;
	}
	public void  setMingcheng(java.lang.String mingcheng) {
		this.mingcheng = mingcheng;
	}

    /*��������*/


}
