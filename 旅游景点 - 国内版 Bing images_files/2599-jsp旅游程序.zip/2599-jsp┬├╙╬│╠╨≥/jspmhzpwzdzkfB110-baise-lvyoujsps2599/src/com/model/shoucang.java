package com.model;

/**
 * shoucang entity. @author MyEclipse Persistence Tools
 */

public class shoucang implements java.io.Serializable
{
    /*������*/
	private  java.lang.Integer  id;
	private  java.lang.String  shijian;
	private  java.lang.Integer  jingdianid;
	private  java.lang.Integer  usersid;

    /*��������*/
	private jingdian jingdian;
	private users users;

    /*�з���*/
	public java.lang.Integer  getId() {
		return id;
	}
	public void  setId(java.lang.Integer id) {
		this.id = id;
	}
	public java.lang.String  getShijian() {
		return shijian;
	}
	public void  setShijian(java.lang.String shijian) {
		this.shijian = shijian;
	}
	public java.lang.Integer  getJingdianid() {
		return jingdianid;
	}
	public void  setJingdianid(java.lang.Integer jingdianid) {
		this.jingdianid = jingdianid;
	}
	public java.lang.Integer  getUsersid() {
		return usersid;
	}
	public void  setUsersid(java.lang.Integer usersid) {
		this.usersid = usersid;
	}

    /*��������*/
	public jingdian  getJingdian() {
		return jingdian;
	}
	public void  setJingdian(jingdian jingdian) {
		this.jingdian = jingdian;
	}
	public users  getUsers() {
		return users;
	}
	public void  setUsers(users users) {
		this.users = users;
	}


}
