package com.model;

/**
 * lianjie entity. @author MyEclipse Persistence Tools
 */

public class lianjie implements java.io.Serializable
{
    /*������*/
	private  java.lang.Integer  id;
	private  java.lang.String  name;
	private  java.lang.String  url;

    /*��������*/

    /*�з���*/
	public java.lang.Integer  getId() {
		return id;
	}
	public void  setId(java.lang.Integer id) {
		this.id = id;
	}
	public java.lang.String  getName() {
		return name;
	}
	public void  setName(java.lang.String name) {
		this.name = name;
	}
	public java.lang.String  getUrl() {
		return url;
	}
	public void  setUrl(java.lang.String url) {
		this.url = url;
	}

    /*��������*/


}
