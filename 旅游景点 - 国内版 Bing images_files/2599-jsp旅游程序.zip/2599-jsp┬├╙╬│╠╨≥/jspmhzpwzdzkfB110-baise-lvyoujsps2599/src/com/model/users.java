package com.model;

/**
 * users entity. @author MyEclipse Persistence Tools
 */

public class users implements java.io.Serializable
{
    /*������*/
	private  java.lang.Integer  id;
	private  java.lang.String  loginname;
	private  java.lang.String  loginpw;
	private  java.lang.String  xingming;
	private  java.lang.String  xingbie;
	private  java.lang.String  nianling;
	private  java.lang.String  address;
	private  java.lang.String  dianhua;
	private  java.lang.String  shenhe;
	private  java.lang.String  type;
	private  java.lang.String  typename;

    /*��������*/

    /*�з���*/
	public java.lang.Integer  getId() {
		return id;
	}
	public void  setId(java.lang.Integer id) {
		this.id = id;
	}
	public java.lang.String  getLoginname() {
		return loginname;
	}
	public void  setLoginname(java.lang.String loginname) {
		this.loginname = loginname;
	}
	public java.lang.String  getLoginpw() {
		return loginpw;
	}
	public void  setLoginpw(java.lang.String loginpw) {
		this.loginpw = loginpw;
	}
	public java.lang.String  getXingming() {
		return xingming;
	}
	public void  setXingming(java.lang.String xingming) {
		this.xingming = xingming;
	}
	public java.lang.String  getXingbie() {
		return xingbie;
	}
	public void  setXingbie(java.lang.String xingbie) {
		this.xingbie = xingbie;
	}
	public java.lang.String  getNianling() {
		return nianling;
	}
	public void  setNianling(java.lang.String nianling) {
		this.nianling = nianling;
	}
	public java.lang.String  getAddress() {
		return address;
	}
	public void  setAddress(java.lang.String address) {
		this.address = address;
	}
	public java.lang.String  getDianhua() {
		return dianhua;
	}
	public void  setDianhua(java.lang.String dianhua) {
		this.dianhua = dianhua;
	}
	public java.lang.String  getShenhe() {
		return shenhe;
	}
	public void  setShenhe(java.lang.String shenhe) {
		this.shenhe = shenhe;
	}
	public java.lang.String  getType() {
		return type;
	}
	public void  setType(java.lang.String type) {
		this.type = type;
	}
	public java.lang.String  getTypename() {
		return typename;
	}
	public void  setTypename(java.lang.String typename) {
		this.typename = typename;
	}

    /*��������*/


}
